// Author: Amine Benelbar
// Project 2, Designing a virtual Manager
// Program essentially mimics address-translation proccess using an LRU replacement to replaces
// pages and frames from the TLB and the second chance algorithm to replace the page content in
// frames belonging to physical memory

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <errno.h>
#include <string>
#include <cstring>
#include <stdio.h>
using namespace std;
const int PAGE_SIZE = 256;
const int FRAME_SIZE = 256; // Seems useless. Does the page table contain the content of the frames or is it only available in memory???
const int PHYS_MEM = 128; // change to 128. If that happens "Page frameNum: -1" keeps getting reported. 
const int TLB_SIZE = 16;
int main ()
{
int logicalAddress; // logical address
int logAddressCopy; // Contains copy of the logical address for restarting purposes in case of a page miss
bool restart = false; // Flag to restart getting page conetent or not.
int pageNum = 0;
int offset = 0;
int frameNum = 0;  // frame number tells where to look in and offset tells where to look in to that slot. Assigned 
int pgHit = 0; // page fault
int tlbHit = 0; // if 1 its a hit if 0 tlb is a miss and go to page table 
double pgHitAmount =0;// count page hits
double tlbHitAmount =0;// count tlb hits
double pgMissAmount =0;  // count page misses
double tlbMissAmount =0; // count tlb misses
double pgFaultRate =0; // page fault rate
double tlbHitRate =0; // tlb rate 
int tlb[TLB_SIZE][2];
int pageTable[PAGE_SIZE][3]; // Everything is invalid intially. The 3rd part of array contains age of frame
char phyMem[PHYS_MEM][PAGE_SIZE];// Memory of 128 bytes that contains content of pages indexed by frame number. Contents from BACKIN_STOREE
                     // Physical memory contaisn not pages but the content in those pages.
bool parMem[PHYS_MEM][2]; // parrelel array to phyMem to see if physical memory content or not in its
                                   // respective frames and to see whether frame was used or not for second chance(clock) replacement algorithm              
                                 // Initallized all to false values
bool full = false;  
bool notFull = true;                              
int frameAge = 0;
int oldest =0; // Contains the index of the currently oldest value;
int max; // may contain currently oldest value;
string pageContent; // Contains content of a particular page number;
int phyAddress; // Contains physical address
int value; // Contains value of byte located in physical address
//char* null = NULL;


for(int i = 0; i < 16; i++)
{
   tlb[i][0] = -1; // Page number =-1. Their negetive one b/c used as index. 0 is a valid index
   tlb[i][1] = -1; // frame number =-1. Their negetive one b/c used as index. 0 is a valid index
   tlb[i][2] = 0; // Giving initial values for age of frame 
}

// Initializing page table
for(int i = 0; i < PAGE_SIZE; i++)
{
   pageTable[i][0] = -1; // Set frame numbers to -1
   pageTable[i][1] = 0; // 0 represents invalid bit
}

for(int i = 0; i < PHYS_MEM; i++)
{
   parMem[i][0] = false; // Set to false to tell whether physical memory is empty or not
   parMem[i][1] = false; // Set to false or zero to tell whether frame was used, (clock algorithm)0 represents invalid bit
}


 ifstream myFile;
 myFile.open("addresses.txt");
  ofstream file2;
  file2.open("file2binCheck.txt");
   if(myFile.is_open())
   {
      for(int counter = 0; counter < 1000; counter++) // Reading reading 100 logical address
      {

      if(restart) // If restart true
     {
         logicalAddress = logAddressCopy;
         pageNum = (logicalAddress >> 8); // Get first right most bits
         offset = logicalAddress & 255;
        offset = logicalAddress & 255;
        restart = false;
     } 
     
     else
     {
         cout << "count: " << counter << " ";
         myFile >> logicalAddress;
         cout << "Virtual address: " << logicalAddress << endl;
        pageNum = (logicalAddress >> 8); // Get first right most bits
        cout << "Page Number: " << pageNum << endl;
        offset = logicalAddress & 255;
        cout << "offset: " << offset << endl;
     }    
   

     tlbHit=0; // before look table do not want to assume that there are any hits.
     pgHit=0;
     
    for(int i = 0; i < TLB_SIZE; i++)
    {
       if(tlb[i][0] == pageNum) // tlb double array needs tp contain frame number
       {
              tlbHit = 1;
              cout << "TLB HIT" << endl;
              tlbHitAmount++;
              //break;
              // Get frame number
             frameNum = tlb[i][1]; // Get frame number to search in memory
            tlb[i][2] = ++frameAge; // Store age of data data was stored in tlb
            break; // Break out of for loop when a hit is made. 
            // I do not want to search the page table when their is a hit but I ant to search memory       
       }
    }    
        if(!(tlbHit))
        {
            cout << "Tlb Miss" << endl;
            tlbMissAmount++;
           if(pageNum < PAGE_SIZE) // page number is the index of the page table. Do not want to reset vallue of page number given by user. Does not increment page table
           {  
               if(pageTable[pageNum][1] == 1)
               {
                 pgHit = 1;
                 pgHitAmount++;
                 printf("Page HIT\n");
                    for(int j = 0; j < 16; j++ )
                    {
                        max = tlb[0][3]; // max = oldest age
                        //int oldest =0; // Contains oldest value. page replacement for tlb LRU. tlb with oldest age is replaced.
                        if(tlb[j][3] > max)
                        {
                              max= tlb[j][2]; // find max age
                              oldest = j; // contains position of maximum age in tlb
                        }                         
                    }
                 
                 cout << "Updating tlb" << endl;
                 tlb[oldest][0] = pageNum; // Giving tlb the page number
                 tlb[oldest][1] = pageTable[pageNum][0]; // If page hit, tlb gets that frame number in it.
                 frameNum = pageTable[pageNum][0]; // Assigning frame number
                 tlb[oldest][2] = 0; // Since tlb page and frame number replaced it is the newest frame number
                 
                 // What are the reprocautions of this. oldest is calculated whenever 
                 //their is a tlb miss. If their is a page miss, it is only replaced 
                 //after physical memory is accesed
                 
                 cout <<"tlb pgNum: " << tlb[oldest][0] << " tlbFrame: " << tlb[oldest][1] << endl;
                 //break; It is commented b/c to prevent it stoping program to read addresses.
                 
               }  
                               
                 else
                 {
                     cout << "Page Miss" << endl;
                     pgMissAmount++;
                     ifstream myBin;
                     myBin.open("BACKING_STORE.bin",ios::binary);
                     if(myBin.is_open())
                     {
                        //seekg.Sets the position of the next character to be extracted from the input stream.
                        //https://en.wikipedia.org/wiki/Seekg
                            int j = 0;
                           j = pageNum * PAGE_SIZE; // suppose to represent place in mem start to get page                      
                           myBin.seekg(j);
                           //myBin.seekg(256,myBin.cur); // Reading from a binary file

                           
                           // 2nd chance first finds page that will replace exists in memory or not
                           // strcmp compares it with all of the string in memory. circular buffer and contains
                           // a pointer. If pointer is maximum value 128, it becomes 0 on that call
                           // https://github.com/dileep98490/Operating-Systems/blob/master/Page%20replacement%20algorithms/Secondchance.c  
                        
                        for(int i = 0; i < PHYS_MEM; i++) // May change to 128. Can't find page number to replace as its just a bunch of binary numbers here.
                        {                                         
                           
                           // Do not need to check whether the frame content already exists or not b/c of page miss
                           
//                               for(int e = 0 e < PHYS_MEM; e++)
//                               {
//                                   if(phyMem[e] ==  phyMem[frameNum])
//                                   {
//                                        parMem[i][1] = true; // set invalid bit to true in other words 1 if page content already exists
//                                   }
//                               }
                              
                          //get info if empty
                           if(!(parMem[i][0])) //  not parMem[i][0] Page replacement algorithm. If page has nothing or it is the begining of physical memory in memory than replace it for now
                           {
                              // Put content into respective frame
                              myBin.read(phyMem[i],PAGE_SIZE); // i represents frame number. Read 256 bytes of memory in it
                              pageContent = phyMem[i];
                              frameNum = i;
                              // update tables
                              cout << "Upating Page tables" << endl;
                              cout << "Frame: " << frameNum << endl;
                              pageTable[pageNum][0] = frameNum;
                              pageTable[pageNum][1] = 1; // What additionally purpose does this have besides identifiying page misses?
                              parMem[i][0] = true; // now place in pphysical memory is declared not empty
                              parMem[i][1] = true; // Set use bit to true or 1
                              if(i >= (PHYS_MEM-1))
                              {
                                 full = true;
                                 //notFull = false;
                              }
//                               if(i >= (PHYS_MEM-1)) // If at end of array make all values false and start from begining mimicking the FIFO page replacement algorithm
//                               {           // outer for loop should start again
//                                  for(int r = 0; r < PHYS_MEM; r++)
//                                  {
//                                     parMem[r][0] = false;
//                                  }
// 
//                                  i=0;
//                               }
                          //     tlb[oldest][0] = pageNum; // Giving tlb the page number
//                               tlb[oldest][1] = i; // If page hit, tlb gets that frame number in it. i here serves as frame number
//                               tlb[oldest][2] = 0; // Since it has been replaced oldest is now the newest.
                              //Only page table gets updated
                              break; // Suppose to break out of loop
                           }                            
   
                        } 
                        
                               if(full) // If at end of array make all values false and start from begining mimicking the FIFO page replacement algorithm
                              {           // outer for loop should start again
                                 for(int r = 0; r < PHYS_MEM; r++)
                                 {
                                   
                                    
                                    if(!(parMem[r][1])) // if use bit equlas false or 0 in other words
                                    {
                                 // Put content into respective frame
                                 // I'm altering where that page content or where 256 bytes of memory is read is located in the physical memory. What is being read is not being altered just where it goes in physical memory
                                 myBin.read(phyMem[r],PAGE_SIZE); // i represents frame number. Read 256 bytes of memory in it
                                 pageContent = phyMem[r];
                                 frameNum = r;
                                 // update tables
                                 cout << "Upating Page tables" << endl;
                                 cout << "Frame: " << frameNum << endl;
                                 pageTable[pageNum][0] = frameNum;
                                 pageTable[pageNum][1] = 1; // What additionally purpose does this have besides identifiying page misses?
                                 //parMem[i][0] = true;
                                 parMem[r][1] = true; // Set use bit to true or 1
                                 break; // Once finds its spot it will stop looping
                                    }
                                    
                                    else
                                    {
                                       parMem[r][1] = false; // If use bit =1, make it 0 if the physical memoty is not full
                                    }
                                    
                                    if(r >= (PHYS_MEM -1))
                                    {
                                       r=-1; // set to -1 b/c for loop will increment it 0 starting loop all over again making the circular buffer
                                    }
                                 }

                              }
                        
                              //cout <<"tlb pgNum: " << tlb[oldest][0] << " tlbFrame: " << tlb[oldest][1] << endl;
                              cout <<"Page frameNum: " << pageTable[pageNum][0] << endl;                       
                         
                     }
                     
                     else 
                     {
                        cout << "Error opening myBin %s: %s\n", myBin, "\n";
                        break;
   
                     }
                     
                 }       
             }   // page hits and misses handled      
      } // If tlb hit skip all the way here


        if(tlbHit || pgHit) // Display all physical address and values even the ones that h
        {
   
           // Get first right most 8 bits of logical address to get page number
           value = phyMem[frameNum][offset];
           cout <<"FrameNum " << frameNum << endl << endl;
           frameNum = frameNum << 8;
           phyAddress = frameNum + offset;
           cout << "Physical address: " << phyAddress << " value: " << value << endl; 
//             ofstream file2;
//             file2.open("file2binCheck.txt");
            file2 << "counter: " << counter << " " << "Physical address: " << phyAddress << " value: " << value << endl; 
         } 
         
         else
         {
            
            // Cause program to restart to find the phsical address and value of the logical address that initially resulted in a page miss
            counter--; // Done to prevent outer for loop from reading less logical address despite restarting
           // frameNum--; // Should be decremented. Want to be in same position frame number was in before restart happened?
            logAddressCopy = logicalAddress;
            if(tlbHit)
            {
               tlbHitAmount--;
            }
             // Done because will surely be a hit once it restarts
            else
            {
               pgHitAmount--;
            }
            restart = true;

            //parMem[frameNum] = false; //?? Want to be in same position frame number was in before restart happened? The only way for something to bewritten into physical memory is for it to first say their is nothing their and like any "empty memory fill it
            //--frameNum;

            
         }    
     
      } // End of reading address
      
      tlbHitRate =  tlbHitAmount / tlbMissAmount;
      tlbHitRate *= 100;
      pgFaultRate = pgMissAmount / pgHitAmount;
      pgFaultRate *= 100;
       
      cout << endl;
      cout << "TLB HIT RATE: " << tlbHitRate << "%" << endl; // 
      cout << "Page FAULT RATE: " << pgFaultRate << "%" << endl; // 
      file2 << endl;
      file2 << "TLB HIT RATE: " << tlbHitRate << "%" << endl; // Write tlb hit rate in memory
      file2 << "Page FAULT RATE: " << pgFaultRate << "%" << endl; // Write page hit rate in memory
      

   }
       
  else 
  {
      cout << "Error opening a file %s: %s\n", myFile, "\n";
      exit(0);
  }

 
 myFile.close();



return 0;
}
